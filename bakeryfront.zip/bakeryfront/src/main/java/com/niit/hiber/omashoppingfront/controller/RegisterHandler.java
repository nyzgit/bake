package com.niit.hiber.omashoppingfront.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.niit.hiber.omashoppingbackend.dao.AddressDAO;
import com.niit.hiber.omashoppingbackend.dao.CartDAO;
import com.niit.hiber.omashoppingbackend.dao.UserDAO;
import com.niit.hiber.omashoppingbackend.dto.Address;
import com.niit.hiber.omashoppingbackend.dto.Cart;
import com.niit.hiber.omashoppingbackend.dto.User;

@Component
public class RegisterHandler {
	@Autowired
	private UserDAO userDAO;
	@Autowired
	private AddressDAO addressDAO;
    @Autowired
	private CartDAO cartDAO;
	// if you have a separate model
	public RegisterModel initFlow() {
		return new RegisterModel();
	}

	public String saveUser(RegisterModel registerModel, User user) {
		registerModel.setUser(user);
		return null;

	}

	public String saveAddress(RegisterModel registerModel, Address address) {
		registerModel.setBillingAddress(address);
		return null;
	}

	public void saveRegistrationDetails(RegisterModel registerModel) {
		User user = registerModel.getUser();
		
		Cart cart=new Cart();
		registerModel.setCart(cart);
		System.out.println("cart is object::::::::::::::::::::::"+cart);
		
		cart.setUser(user);
		user.setCart(cart);
		
		
		// save the user userDAO.add(user);
		Address billingAddress = registerModel.getBillingAddress();

		
		
		user.getAddress().add(billingAddress);

		// set the user
		billingAddress.setUser(user);
		
		// save the billing address
		userDAO.add(user);
//		addressDAO.add(billingAddress);

	}
	// if user is not supplier
	
	 /* if (user.getRole().equals("CUSTOMER")) { 
		  Cart cart = new Cart(); // set the user
		  cart.setUser(user); // save the cart 
		  userDAO.addUserCart(cart);
	  }*/
	 
}
